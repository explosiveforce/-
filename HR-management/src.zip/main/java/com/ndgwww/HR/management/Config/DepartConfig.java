package com.ndgwww.HR.management.Config;

import com.ndgwww.HR.management.pojo.Department;
import org.apache.ibatis.jdbc.SQL;

public class DepartConfig {

    //更新
    public String update(Department department) {
        return new SQL() {{
            UPDATE("department");
            if (department.getName()!= null) {
                SET("name = #{name}");
            }
            if (department.getTelephone()!= null) {
                SET("telephone = #{telephone}");
            }
            WHERE("id = #{id}");
        }}.toString();
    }

}
