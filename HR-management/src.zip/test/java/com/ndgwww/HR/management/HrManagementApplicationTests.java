package com.ndgwww.HR.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
